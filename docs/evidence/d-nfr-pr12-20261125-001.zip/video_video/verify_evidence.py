"""Reopen article/subtitle evidence; no generation requests."""
from pathlib import Path
import json,urllib.request,re
base=Path(__file__).resolve().parent
for profile in ['video_video']:
 out=base;manifest=json.loads((out/'manifest.json').read_text());checks=[]
 originals={cid:json.loads((out/meta['file']).with_suffix('.json').read_text()) for cid,meta in manifest['source_snapshots'].items()}
 for run in (1,2):
  for path in sorted((out/f'run-{run}').glob('D-*.json')):
   body=json.loads(path.read_text());result=body.get('result',body)
   if 'elapsed_seconds' not in body.get('localEvaluation',{}):continue
   for source in result.get('sources',[]):
    cid=source['contentId'];meta=manifest['source_snapshots'][cid]
    if source.get('sourceVersion') and source['sourceVersion']!=meta['version']:
     checks.append({'run':run,'case_id':path.stem,'contentId':cid,'ok':False,'issue':'snapshot_version_differs_from_frozen_source'})
    for ref in source.get('citations') or []:
     item={'run':run,'case_id':path.stem,'contentId':cid,'citation':ref,'ok':False,'subtitle':meta['kind']=='subtitle'}
     if ref.get('status')!='verified':item['issue']='citation_not_verified';checks.append(item);continue
     request=urllib.request.Request('http://127.0.0.1:7380/api/ai/compare/evidence',data=json.dumps(ref).encode(),headers={'Content-Type':'application/json'})
     try:
      with urllib.request.urlopen(request,timeout=10) as response:e=json.load(response)
      item['evidence']=e
      valid=ref.get('contentId')==cid and e.get('contentId')==cid and ref.get('sourceVersion')==meta['citation_version'] and e['text'][e['startRune']:e['endRune']]==ref['quote']
      if item['subtitle']:
       match=re.fullmatch(r'subtitle:([^:]+):(\d+)-(\d+)',ref['locator']);cues=originals[cid]['track']['cues']
       valid=valid and bool(match) and match[1]==meta['language'] and int(match[3])<len(cues)
       if valid:
        expected=cues[int(match[2])]['start'];valid=e.get('startSeconds') is not None and abs(e['startSeconds']-expected)<=.002
        item['expected_start_seconds']=expected
      item['ok']=bool(valid)
      if not valid:item['issue']='source_version_range_or_subtitle_time_mismatch'
     except Exception as error:item['issue']=type(error).__name__
     checks.append(item)
 summary={'profile':profile,'checks':len(checks),'subtitle_checks':sum(c.get('subtitle',False) for c in checks),'failed':sum(not c['ok'] for c in checks),'model_calls':0,'semantic_support':'Not established by exact source/quotation/time matching.'}
 (out/'evidence-reopens.json').write_text(json.dumps({'summary':summary,'checks':checks},ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(summary),flush=True)
