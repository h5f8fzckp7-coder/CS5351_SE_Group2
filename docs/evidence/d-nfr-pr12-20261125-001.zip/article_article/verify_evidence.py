"""Check saved case evidence through the running local app; no model calls."""
from pathlib import Path
import json, urllib.request, urllib.error
out=Path(__file__).resolve().parent
manifest=json.loads((out/'manifest.json').read_text())
base='http://127.0.0.1:7380/api'
checks=[]
for run in (1,2):
 for path in sorted((out/f'run-{run}').glob('D-*.json')):
  body=json.loads(path.read_text());result=body.get('result',body)
  if 'elapsed_seconds' not in body.get('localEvaluation',{}):continue
  for source in result.get('sources',[]):
   cid=source['contentId']; expected=manifest['source_snapshots'].get(cid,{}).get('version')
   if source.get('sourceVersion') and source['sourceVersion']!=expected:
    checks.append({'run':run,'case_id':path.stem,'contentId':cid,'ok':False,'issue':'source_version_differs_from_frozen_snapshot'})
   for ref in source.get('citations') or []:
    item={'run':run,'case_id':path.stem,'contentId':cid,'citation':ref,'ok':False}
    if ref.get('status')!='verified':
     item['issue']='citation_not_verified';checks.append(item);continue
    request=urllib.request.Request(base+'/ai/compare/evidence',data=json.dumps(ref).encode(),headers={'Content-Type':'application/json'})
    try:
     with urllib.request.urlopen(request,timeout=10) as response:evidence=json.load(response)
     item['evidence']=evidence
     item['ok']=(ref.get('contentId')==cid and evidence.get('contentId')==cid and ref.get('sourceVersion')==expected and evidence['text'][evidence['startRune']:evidence['endRune']]==ref['quote'])
     if not item['ok']:item['issue']='source_version_or_range_mismatch'
    except Exception as error:item['issue']=type(error).__name__
    checks.append(item)
summary={'checks':len(checks),'failed':sum(not x['ok'] for x in checks),'model_calls':0,'semantic_support':'Not established by exact source/quotation matching.'}
(out/'evidence-reopens.json').write_text(json.dumps({'summary':summary,'checks':checks},ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary))
